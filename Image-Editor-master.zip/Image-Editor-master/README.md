My project is a  Image Editor with Basic Image Enhancement options like cropping, rotating, 
colour enhancements, colour Pop and various filters.

The only library I have  which is not built in is the Python Imaging Library.
It can be downloaded via this link.
( http://www.pythonware.com/products/pil/)

The "Make Desktop Bk" has only been implemented for Windows. It will not work on other platforms.
Please disbale that function and the Button created to use that function if you plan to use
the Image Editor on any OS other than Windows.

Here's a demo : https://www.youtube.com/watch?v=8S7faOaI5KI
